self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "194577a7e20bdcc7afbb718f502c134c",
    "url": "/.DS_Store"
  },
  {
    "revision": "790df41c2ada468c13ae",
    "url": "/404.2e01aa17c4a4a5cb5abf.css"
  },
  {
    "revision": "790df41c2ada468c13ae",
    "url": "/404.f299a17b2254051cd90f.js"
  },
  {
    "revision": "b07d596684e269307a1319978b4364bd",
    "url": "/android-chrome-192x192.png"
  },
  {
    "revision": "ec79956c040ac87c19b711517134c10d",
    "url": "/android-chrome-512x512.png"
  },
  {
    "revision": "c8972a038dda48010e18a55837b81d3e",
    "url": "/apple-touch-icon.png"
  },
  {
    "revision": "f93f0679c49aef5c9b602a648607c4e1",
    "url": "/bence-somogyi.png"
  },
  {
    "revision": "8577d73a94ccaac2299026b7505d9465",
    "url": "/bence-somogyi@2x.png"
  },
  {
    "revision": "a493ba0aa0b8ec8068d786d7248bb92c",
    "url": "/browserconfig.xml"
  },
  {
    "revision": "a3abe5d2f16c4c8513400ca6d8cbe682",
    "url": "/chatler.png"
  },
  {
    "revision": "acd39174d8100f3853e7d71b115eeca2",
    "url": "/clipdis.png"
  },
  {
    "revision": "28b1371029b79e98f1a6d638e8aa89c6",
    "url": "/emarsys.png"
  },
  {
    "revision": "0e688569afaa05c5c623632c515d9678",
    "url": "/favicon-16x16.png"
  },
  {
    "revision": "3088499e62dbb9374980877ff981b13e",
    "url": "/favicon-32x32.png"
  },
  {
    "revision": "5f5afd8835c11378253e95efb2fc1246",
    "url": "/favicon.ico"
  },
  {
    "revision": "89165f481d98a89f563002797ab46c23",
    "url": "/gabor-dobrei.png"
  },
  {
    "revision": "5cc2693a25dc440a5a7ddfaf230527c3",
    "url": "/gabor-dobrei@2x.png"
  },
  {
    "revision": "a5457316dbcc790c6503",
    "url": "/home.3bcadd5226174d6d75c1.js"
  },
  {
    "revision": "a5457316dbcc790c6503",
    "url": "/home.c8b2d9fd775cfa2992de.css"
  },
  {
    "revision": "c69de8214825d4e7d9eb12fd31f06af9",
    "url": "/judit-dobrei-rakonczai.png"
  },
  {
    "revision": "100e810bba9bd4d17cc8f045b5dbf142",
    "url": "/judit-dobrei-rakonczai@2x.png"
  },
  {
    "revision": "a02cca60f8dae0acc6b5c0e0fe058529",
    "url": "/kpmg.png"
  },
  {
    "revision": "9e4d1d81950d1dfd0af4de9fd50d1d05",
    "url": "/logo-grayscale.svg"
  },
  {
    "revision": "b336df83319c4cd8e0391adcdce7a8ae",
    "url": "/logo.svg"
  },
  {
    "revision": "4dc0634f1ce1f57627321f178e15d74a",
    "url": "/mstile-150x150.png"
  },
  {
    "revision": "f008fb294c3586ad0d7cdaa18422da6d",
    "url": "/nng.png"
  },
  {
    "revision": "460fa0d08cb8c6fb87407f95b37babe6",
    "url": "/og-share.png"
  },
  {
    "revision": "af278cbab167b472a4be5e0867e99165",
    "url": "/pepper.svg"
  },
  {
    "revision": "6937e6deb39b9e97cd8b5413d180d2bd",
    "url": "/richard-szabo.png"
  },
  {
    "revision": "d5bfbfbcdf5b282283b02b8dbc688615",
    "url": "/richard-szabo@2x.png"
  },
  {
    "revision": "474610f6c89ad34f16f265fc8ab92d4b",
    "url": "/richard-tamaska.png"
  },
  {
    "revision": "6da72c9c7e92f8fc7cec2cbf8ec945d7",
    "url": "/richard-tamaska@2x.png"
  },
  {
    "revision": "92bd5f0b31d0f2470a2844e7c9f85ad4",
    "url": "/safari-pinned-tab.svg"
  },
  {
    "revision": "e9d3f66547aa831941ef3f0ad3da0a61",
    "url": "/site.webmanifest"
  },
  {
    "revision": "78bb8b402ecdcf168183ea7e99b6bc83",
    "url": "/supercharge.png"
  },
  {
    "revision": "506b0ba814680939e1a53b85313f986a",
    "url": "/telekom.png"
  },
  {
    "revision": "1dbd3dc0da20c1b1ae178af199e7cf65",
    "url": "/testimonials.svg"
  },
  {
    "revision": "1df39c01c3c246c85de558bd8e27aaaf",
    "url": "/themealplanner.png"
  },
  {
    "revision": "0caa1798015322f02dda",
    "url": "/vendors.0.145caa8a8267f4db9582.css"
  },
  {
    "revision": "0caa1798015322f02dda",
    "url": "/vendors.998b970df5b224e73982.js"
  }
]);