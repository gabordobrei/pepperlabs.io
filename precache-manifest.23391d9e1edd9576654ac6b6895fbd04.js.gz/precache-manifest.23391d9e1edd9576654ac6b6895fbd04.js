self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "790df41c2ada468c13ae",
    "url": "/404.2e01aa17c4a4a5cb5abf.css"
  },
  {
    "revision": "790df41c2ada468c13ae",
    "url": "/404.f299a17b2254051cd90f.js"
  },
  {
    "revision": "b07d596684e269307a1319978b4364bd",
    "url": "/android-chrome-192x192.png"
  },
  {
    "revision": "ec79956c040ac87c19b711517134c10d",
    "url": "/android-chrome-512x512.png"
  },
  {
    "revision": "c8972a038dda48010e18a55837b81d3e",
    "url": "/apple-touch-icon.png"
  },
  {
    "revision": "a493ba0aa0b8ec8068d786d7248bb92c",
    "url": "/browserconfig.xml"
  },
  {
    "revision": "a3abe5d2f16c4c8513400ca6d8cbe682",
    "url": "/chatler.png"
  },
  {
    "revision": "acd39174d8100f3853e7d71b115eeca2",
    "url": "/clipdis.png"
  },
  {
    "revision": "28b1371029b79e98f1a6d638e8aa89c6",
    "url": "/emarsys.png"
  },
  {
    "revision": "0e688569afaa05c5c623632c515d9678",
    "url": "/favicon-16x16.png"
  },
  {
    "revision": "3088499e62dbb9374980877ff981b13e",
    "url": "/favicon-32x32.png"
  },
  {
    "revision": "5f5afd8835c11378253e95efb2fc1246",
    "url": "/favicon.ico"
  },
  {
    "revision": "fa770c4748790d0dd0f9",
    "url": "/home.3bcadd5226174d6d75c1.js"
  },
  {
    "revision": "fa770c4748790d0dd0f9",
    "url": "/home.fa0427b6efb55593a6f4.css"
  },
  {
    "revision": "9e4d1d81950d1dfd0af4de9fd50d1d05",
    "url": "/logo-grayscale.svg"
  },
  {
    "revision": "b336df83319c4cd8e0391adcdce7a8ae",
    "url": "/logo.svg"
  },
  {
    "revision": "4dc0634f1ce1f57627321f178e15d74a",
    "url": "/mstile-150x150.png"
  },
  {
    "revision": "460fa0d08cb8c6fb87407f95b37babe6",
    "url": "/og-share.png"
  },
  {
    "revision": "dce6143516539c91bcf57b4030b80c5f",
    "url": "/pepper.svg"
  },
  {
    "revision": "92bd5f0b31d0f2470a2844e7c9f85ad4",
    "url": "/safari-pinned-tab.svg"
  },
  {
    "revision": "e9d3f66547aa831941ef3f0ad3da0a61",
    "url": "/site.webmanifest"
  },
  {
    "revision": "78bb8b402ecdcf168183ea7e99b6bc83",
    "url": "/supercharge.png"
  },
  {
    "revision": "506b0ba814680939e1a53b85313f986a",
    "url": "/telekom.png"
  },
  {
    "revision": "1dbd3dc0da20c1b1ae178af199e7cf65",
    "url": "/testimonials.svg"
  },
  {
    "revision": "1df39c01c3c246c85de558bd8e27aaaf",
    "url": "/themealplanner.png"
  },
  {
    "revision": "0caa1798015322f02dda",
    "url": "/vendors.0.145caa8a8267f4db9582.css"
  },
  {
    "revision": "0caa1798015322f02dda",
    "url": "/vendors.998b970df5b224e73982.js"
  }
]);